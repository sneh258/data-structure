
#include <bits/stdc++.h>

using namespace std;

string reverseWords(string s) {
        
        vector<vector<char>>str;
        int y=0,j=0,k=0;
        
        for(int i=0;i<s.length();i++)
        {
            
            k=0;
            
            if(s[i]!= ' ')
            {
                str[y][k++]=s[i];
                
            }
            y++;
            
             
        }
         k=0;
        
        reverse(str.begin(),str.end());
        
        char x[s.length()];
        
        for(int i=0;i<str.size();i++)
        {
            for(int j=0;j<str[i].size();j++)
            {
            
            x[k++]+=str[i][j];
            }
            //x=x+" ";
        }
        cout<<x;
        return x;
        
    }

int main()
{
    string s="the sky is blue";
    cout<<reverseWords(s);

    return 0;
}
