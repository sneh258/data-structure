#include <bits/stdc++.h>
using namespace std;

int main()
{
   unordered_map<int,int>m;
   
   for(int i=0;i<10;i++)
  {
      if(m.find(i)!=m.end())
      m.insert(make_pair(i,1));
      else
      m[i]++;
  }
  
  for (auto& it : m) {
        cout << it.first << ' ' << it.second << '\n';
    }
    
    cout<<m[9];
   
   

    return 0;
}