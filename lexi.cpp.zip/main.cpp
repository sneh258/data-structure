#include<bits/stdc++.h>
using namespace std;

void rp(vector<vector<int>>ans,vector<int>ds,vector<int>f,vector<int>nums)
{
    if(ds.size()==nums.size())
    {
        ans.push_back(ds);
        return;
    }
    
    for(int i=0;i<nums.size();i++)
    {
        if(!f[i])
        {
            ds.push_back(nums[i]);
            f[i]=1;
            rp(ans,ds,nums,f);
            f[i]=0;
            ds.pop_back();
        }
        
    }
}

vector<vector<int>> p(vector<int>nums)
{
    vector<vector<int>> ans;
    vector<int>ds;
    vector<int> f;
    
    rp(ans,ds,nums,f);
    return ans;
}

int main()
{
    vector<int> nums={1,2,3};
    
    vector<vector<int>>s;
    s=p(nums);
    
    for (int i = 0; i < s.size(); i++)
    {
        for (int j = 0; j < s.size(); j++)
        {
            cout << s[i][j] << " ";
        }    
        cout << endl;
    }

    return 0;
}
    
    
    
    
    
    
    
    







