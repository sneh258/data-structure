
#include<iostream>
#include<vector>
using namespace std;


int findDuplicate(vector<int>& nums) {
        
        vector<int> f;
        int ans;
        
        for(int i=0;i<nums.size();i++)
            f[nums[i]]++;
        for(int i=0;i<f.size();i++)
        {
            if(f[i]>1)
              ans=f[i];  
        }
        return ans;
    }


int main()
{
    vector<int> nums{1,1,2,3,4};
    int y=findDuplicate(nums);
}